package com.example.handcursor;

import net.minecraft.class_310;
import net.minecraft.class_364;
import net.minecraft.class_437;
import net.minecraft.class_5250;

/**
 * Màn hình cài đặt hiển thị qua ModMenu.
 * Cho phép chỉnh scale (kích thước tay), shoulderX, allScreens, v.v. trong game.
 */
public class HandConfigScreen extends class_437 {

    private final class_437 parent;

    public HandConfigScreen(class_437 parent) {
        super(class_5250.method_43471("handcursor.config.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() { // init()
        HandConfig cfg = HandConfig.get();
        int centerX = this.field_22789 / 2;
        int y = 40;

        // ---------- Nút tăng / giảm SCALE ----------
        // Scale - 0.5
        this.method_37063(new class_364(
                centerX - 120, y, 115, 20,
                class_5250.method_43471("§7Scale: " + String.format("%.1f", cfg.scale) + "  ▼ -0.5"),
                btn -> {
                    cfg.scale = Math.max(1.0f, cfg.scale - 0.5f);
                    // Mở lại screen để refresh label
                    class_310.method_1551().method_1507(new HandConfigScreen(parent));
                },
                class_364.field_22765
        ));
        // Scale + 0.5
        this.method_37063(new class_364(
                centerX + 5, y, 115, 20,
                class_5250.method_43471("§7Scale: " + String.format("%.1f", cfg.scale) + "  ▲ +0.5"),
                btn -> {
                    cfg.scale = Math.min(12.0f, cfg.scale + 0.5f);
                    class_310.method_1551().method_1507(new HandConfigScreen(parent));
                },
                class_364.field_22765
        ));
        y += 28;

        // ---------- All Screens toggle ----------
        this.method_37063(new class_364(
                centerX - 120, y, 240, 20,
                class_5250.method_43471("§7All Screens: " + (cfg.allScreens ? "§aON" : "§cOFF")),
                btn -> {
                    cfg.allScreens = !cfg.allScreens;
                    class_310.method_1551().method_1507(new HandConfigScreen(parent));
                },
                class_364.field_22765
        ));
        y += 28;

        // ---------- Shoulder X Left ----------
        this.method_37063(new class_364(
                centerX - 120, y, 115, 20,
                class_5250.method_43471("§7Left shoulder ◄"),
                btn -> {
                    cfg.leftShoulderX = Math.max(0.05f, cfg.leftShoulderX - 0.05f);
                    class_310.method_1551().method_1507(new HandConfigScreen(parent));
                },
                class_364.field_22765
        ));
        this.method_37063(new class_364(
                centerX + 5, y, 115, 20,
                class_5250.method_43471("§7Left shoulder ►"),
                btn -> {
                    cfg.leftShoulderX = Math.min(0.49f, cfg.leftShoulderX + 0.05f);
                    class_310.method_1551().method_1507(new HandConfigScreen(parent));
                },
                class_364.field_22765
        ));
        y += 28;

        // ---------- Nút Done ----------
        this.method_37063(new class_364(
                centerX - 60, this.field_22790 - 30, 120, 20,
                class_5250.method_43471("Done"),
                btn -> class_310.method_1551().method_1507(parent),
                class_364.field_22765
        ));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) { // render()
        this.method_73874(context); // renderBackground
        HandConfig cfg = HandConfig.get();
        int cx = this.field_22789 / 2;

        // Tiêu đề
        context.method_25303(this.field_2486,
                "§l§eHand Cursor §r§7- Settings",
                cx, 12, 0xFFFFFF);

        // Hiển thị giá trị hiện tại
        context.method_25303(this.field_2486,
                "Scale: §b" + String.format("%.1f", cfg.scale)
                + "   Left shoulder: §b" + String.format("%.2f", cfg.leftShoulderX),
                cx, 28, 0xAAAAAA);

        super.method_25394(context, mouseX, mouseY, delta);
    }
}
