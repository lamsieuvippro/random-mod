package com.example.handcursor;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;

public class HandCursorClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!shouldApply(screen)) {
                return;
            }
            setCursorHidden(client, true);

            ScreenEvents.afterRender(screen).register((s, drawContext, mouseX, mouseY, tickDelta) ->
                    HandRenderer.render(client, drawContext, s, mouseX, mouseY));

            ScreenEvents.remove(screen).register(s -> setCursorHidden(client, false));
        });
    }

    private static boolean shouldApply(class_437 screen) {
        return HandConfig.get().allScreens || screen instanceof class_465<?>;
    }

    private static void setCursorHidden(class_310 client, boolean hidden) {
        long window = client.method_22683().method_4490();
        GLFW.glfwSetInputMode(window, GLFW.GLFW_CURSOR,
                hidden ? GLFW.GLFW_CURSOR_HIDDEN : GLFW.GLFW_CURSOR_NORMAL);
    }
}
