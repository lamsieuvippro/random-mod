package com.example.handcursor;

import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_8685;
import org.joml.Matrix3x2fStack;

/**
 * Vẽ cánh tay của người chơi (lấy từ skin) vươn từ mép dưới màn hình tới vị trí chuột.
 * Đầu bàn tay nằm đúng tại điểm click.
 */
public final class HandRenderer {
    private static final int TEX_SIZE = 64;

    private HandRenderer() {}

    public static void render(class_310 client, class_332 ctx, class_437 screen, int mouseX, int mouseY) {
        if (client.field_1724 == null) {
            return;
        }
        HandConfig cfg = HandConfig.get();

        class_8685 skin = client.field_1724.method_52814();
        class_2960 tex = skin.comp_1626().comp_3627();
        boolean slim = String.valueOf(skin.comp_1629()).toUpperCase().contains("SLIM");

        int w = screen.field_22789;
        int h = screen.field_22790;

        float leftX  = w * cfg.leftShoulderX;
        float rightX = w * cfg.rightShoulderX;
        float shoulderY = h + cfg.shoulderOffsetY;

        boolean useLeft = mouseX < w / 2;

        if (useLeft) {
            drawArm(ctx, tex, false, slim, rightX, shoulderY, rightX - 15f, h - 24f, cfg);
            drawArm(ctx, tex, true,  slim, leftX,  shoulderY, mouseX, mouseY, cfg);
        } else {
            drawArm(ctx, tex, true,  slim, leftX,  shoulderY, leftX + 15f, h - 24f, cfg);
            drawArm(ctx, tex, false, slim, rightX, shoulderY, mouseX, mouseY, cfg);
        }
    }

    private static void drawArm(class_332 ctx, class_2960 tex, boolean left, boolean slim,
                                float ax, float ay, float tx, float ty, HandConfig cfg) {
        float scale     = cfg.scale;
        int   handRows  = cfg.handRows;

        float dx = tx - ax;
        float dy = ty - ay;
        int length = Math.max(Math.round((float) Math.hypot(dx, dy) / scale), handRows * 2);
        float angle = (float) Math.atan2(-dx, dy);

        int width = slim ? 3 : 4;
        int x     = slim ? -1 : -2;

        int baseU  = left ? 36 : 44, baseV  = left ? 52 : 20;
        int sleeveU = left ? 52 : 44, sleeveV = left ? 52 : 36;

        Matrix3x2fStack m = ctx.method_51448();
        m.pushMatrix();
        m.translate(ax, ay);
        m.rotate(angle);
        m.scale(scale, scale);

        drawLayer(ctx, tex, baseU,   baseV,   x, width, length, handRows);
        drawLayer(ctx, tex, sleeveU, sleeveV, x, width, length, handRows);

        m.popMatrix();
    }

    private static void drawLayer(class_332 ctx, class_2960 tex,
                                  int u, int v, int x, int width, int length, int handRows) {
        int armRows = 12 - handRows;
        ctx.method_25302(class_10799.field_56883, tex,
                x, 0, u, v,
                width, length - handRows,
                width, armRows,
                TEX_SIZE, TEX_SIZE);
        ctx.method_25302(class_10799.field_56883, tex,
                x, length - handRows, u, v + armRows,
                width, handRows,
                width, handRows,
                TEX_SIZE, TEX_SIZE);
    }
}
