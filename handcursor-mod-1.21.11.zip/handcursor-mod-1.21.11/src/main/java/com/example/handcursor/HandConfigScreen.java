package com.example.handcursor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class HandConfigScreen extends Screen {

    private final Screen parent;

    public HandConfigScreen(Screen parent) {
        super(Text.translatable("handcursor.config.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        HandConfig cfg = HandConfig.get();
        int cx = this.width / 2;
        int y = 40;

        // Scale -0.5
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Scale: " + String.format("%.1f", cfg.scale) + "  ▼ -0.5"),
                btn -> {
                    cfg.scale = Math.max(1.0f, cfg.scale - 0.5f);
                    MinecraftClient.getInstance().setScreen(new HandConfigScreen(parent));
                })
                .dimensions(cx - 120, y, 115, 20).build());

        // Scale +0.5
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Scale: " + String.format("%.1f", cfg.scale) + "  ▲ +0.5"),
                btn -> {
                    cfg.scale = Math.min(12.0f, cfg.scale + 0.5f);
                    MinecraftClient.getInstance().setScreen(new HandConfigScreen(parent));
                })
                .dimensions(cx + 5, y, 115, 20).build());
        y += 28;

        // All Screens toggle
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("All Screens: " + (cfg.allScreens ? "ON" : "OFF")),
                btn -> {
                    cfg.allScreens = !cfg.allScreens;
                    MinecraftClient.getInstance().setScreen(new HandConfigScreen(parent));
                })
                .dimensions(cx - 120, y, 240, 20).build());
        y += 28;

        // Left shoulder -
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Left shoulder ◄"),
                btn -> {
                    cfg.leftShoulderX = Math.max(0.05f, cfg.leftShoulderX - 0.05f);
                    MinecraftClient.getInstance().setScreen(new HandConfigScreen(parent));
                })
                .dimensions(cx - 120, y, 115, 20).build());

        // Left shoulder +
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Left shoulder ►"),
                btn -> {
                    cfg.leftShoulderX = Math.min(0.49f, cfg.leftShoulderX + 0.05f);
                    MinecraftClient.getInstance().setScreen(new HandConfigScreen(parent));
                })
                .dimensions(cx + 5, y, 115, 20).build());
        y += 28;

        // Done
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Done"),
                btn -> MinecraftClient.getInstance().setScreen(parent))
                .dimensions(cx - 60, this.height - 30, 120, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        HandConfig cfg = HandConfig.get();
        int cx = this.width / 2;

        context.drawCenteredTextWithShadow(this.textRenderer,
                "Hand Cursor - Settings", cx, 12, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                "Scale: " + String.format("%.1f", cfg.scale)
                + "   Left shoulder: " + String.format("%.2f", cfg.leftShoulderX),
                cx, 28, 0xAAAAAA);

        super.render(context, mouseX, mouseY, delta);
    }
}
