package com.example.handcursor;

/**
 * Cấu hình cho mod Hand Cursor.
 * Chỉnh các giá trị ở đây để thay đổi hiển thị tay.
 */
public class HandConfig {

    /** Tỷ lệ phóng to tay. 2.5 = mặc định, 4.0 = to hơn, 6.0 = rất to. */
    public float scale = 4.0f;

    /** Số hàng pixel của phần bàn tay (đầu ngón) giữ nguyên kích thước. Mặc định 4. */
    public int handRows = 4;

    /** Áp dụng cho MỌI màn hình (true) hay chỉ container có slot (false). */
    public boolean allScreens = false;

    /** Vị trí vai trái theo % chiều rộng màn hình. Mặc định 0.30 (30%). */
    public float leftShoulderX = 0.30f;

    /** Vị trí vai phải theo % chiều rộng màn hình. Mặc định 0.70 (70%). */
    public float rightShoulderX = 0.70f;

    /** Khoảng nhô ra dưới màn hình của điểm vai (pixel). Mặc định 30. */
    public float shoulderOffsetY = 30f;

    // Singleton
    private static HandConfig INSTANCE = new HandConfig();

    public static HandConfig get() {
        return INSTANCE;
    }
}
