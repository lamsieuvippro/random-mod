package com.example.handcursor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public final class HandRenderer {
    private static final int TEX_SIZE = 64;

    private HandRenderer() {}

    public static void render(MinecraftClient client, DrawContext ctx, Screen screen, int mouseX, int mouseY) {
        if (client.player == null) return;
        HandConfig cfg = HandConfig.get();

        SkinTextures skin = client.player.getSkinTextures();
        Identifier tex = skin.texture();
        boolean slim = skin.model() == SkinTextures.Model.SLIM;

        int w = screen.width;
        int h = screen.height;

        float leftX    = w * cfg.leftShoulderX;
        float rightX   = w * cfg.rightShoulderX;
        float shoulderY = h + cfg.shoulderOffsetY;

        boolean useLeft = mouseX < w / 2;

        if (useLeft) {
            drawArm(ctx, tex, false, slim, rightX, shoulderY, rightX - 15f, h - 24f, cfg);
            drawArm(ctx, tex, true,  slim, leftX,  shoulderY, mouseX, mouseY, cfg);
        } else {
            drawArm(ctx, tex, true,  slim, leftX,  shoulderY, leftX + 15f, h - 24f, cfg);
            drawArm(ctx, tex, false, slim, rightX, shoulderY, mouseX, mouseY, cfg);
        }
    }

    private static void drawArm(DrawContext ctx, Identifier tex, boolean left, boolean slim,
                                 float ax, float ay, float tx, float ty, HandConfig cfg) {
        float scale    = cfg.scale;
        int   handRows = cfg.handRows;

        float dx = tx - ax;
        float dy = ty - ay;
        int length = Math.max(Math.round((float) Math.hypot(dx, dy) / scale), handRows * 2);
        float angle = (float) Math.atan2(-dx, dy);

        int width = slim ? 3 : 4;
        int x     = slim ? -1 : -2;

        int baseU   = left ? 36 : 44, baseV   = left ? 52 : 20;
        int sleeveU = left ? 52 : 44, sleeveV = left ? 52 : 36;

        MatrixStack matrices = ctx.getMatrices();
        matrices.push();
        matrices.translate(ax, ay, 0);
        matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotation(angle));
        matrices.scale(scale, scale, 1f);

        drawLayer(ctx, tex, baseU,   baseV,   x, width, length, handRows);
        drawLayer(ctx, tex, sleeveU, sleeveV, x, width, length, handRows);

        matrices.pop();
    }

    private static void drawLayer(DrawContext ctx, Identifier tex,
                                  int u, int v, int x, int width, int length, int handRows) {
        int armRows = 12 - handRows;
        // drawTexture(Identifier, x, y, u, v, width, height, regionWidth, regionHeight, texWidth, texHeight)
        ctx.drawTexture(tex,
                x, 0, u, v,
                width, length - handRows,
                width, armRows,
                TEX_SIZE, TEX_SIZE);
        ctx.drawTexture(tex,
                x, length - handRows, u, v + armRows,
                width, handRows,
                width, handRows,
                TEX_SIZE, TEX_SIZE);
    }
}
