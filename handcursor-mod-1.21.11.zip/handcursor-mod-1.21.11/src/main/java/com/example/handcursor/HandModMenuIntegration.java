package com.example.handcursor;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Kết nối mod với ModMenu để hiển thị nút "Config" trong danh sách mod.
 */
public class HandModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> new HandConfigScreen(parent);
    }
}
