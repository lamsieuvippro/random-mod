package com.example.handcursor;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.lwjgl.glfw.GLFW;

public class HandCursorClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!shouldApply(screen)) return;
            setCursorHidden(client, true);

            ScreenEvents.afterRender(screen).register((s, drawContext, mouseX, mouseY, tickDelta) ->
                    HandRenderer.render(client, drawContext, s, mouseX, mouseY));

            ScreenEvents.remove(screen).register(s -> setCursorHidden(client, false));
        });
    }

    private static boolean shouldApply(Screen screen) {
        return HandConfig.get().allScreens || screen instanceof HandledScreen<?>;
    }

    private static void setCursorHidden(MinecraftClient client, boolean hidden) {
        long window = client.getWindow().getHandle();
        GLFW.glfwSetInputMode(window, GLFW.GLFW_CURSOR,
                hidden ? GLFW.GLFW_CURSOR_HIDDEN : GLFW.GLFW_CURSOR_NORMAL);
    }
}
