package com.example.handcursor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;

/**
 * Vẽ cánh tay của người chơi (lấy từ skin) vươn từ mép dưới màn hình tới vị trí chuột.
 * Đầu bàn tay nằm đúng tại điểm click.
 */
public final class HandRenderer {
    private static final int TEX_SIZE = 64;
    /** 1 pixel của skin = bao nhiêu pixel GUI (độ dày cánh tay). */
    private static final float SCALE = 2.5f;
    /** Chiều cao phần bàn tay (pixel skin) ở đầu cánh tay. */
    private static final int HAND_ROWS = 4;

    private HandRenderer() {}

    public static void render(MinecraftClient client, DrawContext ctx, Screen screen, int mouseX, int mouseY) {
        if (client.player == null) {
            return;
        }
        SkinTextures skin = client.player.getSkin();
        Identifier tex = skin.body().texturePath();
        boolean slim = String.valueOf(skin.model()).toUpperCase().contains("SLIM");

        int w = screen.width;
        int h = screen.height;

        float leftX = w * 0.30f;
        float rightX = w * 0.70f;
        float shoulderY = h + 30f;

        boolean useLeft = mouseX < w / 2;

        // Tay không hoạt động: nằm yên ở mép dưới.
        if (useLeft) {
            drawArm(ctx, tex, false, slim, rightX, shoulderY, rightX - 15f, h - 24f);
            drawArm(ctx, tex, true, slim, leftX, shoulderY, mouseX, mouseY);
        } else {
            drawArm(ctx, tex, true, slim, leftX, shoulderY, leftX + 15f, h - 24f);
            drawArm(ctx, tex, false, slim, rightX, shoulderY, mouseX, mouseY);
        }
    }

    private static void drawArm(DrawContext ctx, Identifier tex, boolean left, boolean slim,
                                float ax, float ay, float tx, float ty) {
        float dx = tx - ax;
        float dy = ty - ay;
        int length = Math.max(Math.round((float) Math.hypot(dx, dy) / SCALE), HAND_ROWS * 2);
        float angle = (float) Math.atan2(-dx, dy); // xoay trục +Y (vai -> bàn tay) về phía chuột

        int width = slim ? 3 : 4;
        int x = slim ? -1 : -2;

        // Mặt trước của tay trong skin 64x64 (lớp thân + lớp áo).
        int baseU = left ? 36 : 44, baseV = left ? 52 : 20;
        int sleeveU = left ? 52 : 44, sleeveV = left ? 52 : 36;

        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(ax, ay);
        m.rotate(angle);
        m.scale(SCALE, SCALE);

        drawLayer(ctx, tex, baseU, baseV, x, width, length);
        drawLayer(ctx, tex, sleeveU, sleeveV, x, width, length);

        m.popMatrix();
    }

    private static void drawLayer(DrawContext ctx, Identifier tex, int u, int v, int x, int width, int length) {
        int armRows = 12 - HAND_ROWS; // 8 hàng đầu = ống tay (kéo giãn theo khoảng cách)
        // Phần cánh tay: kéo giãn theo chiều dài
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex,
                x, 0, u, v,
                width, length - HAND_ROWS,
                width, armRows,
                TEX_SIZE, TEX_SIZE);
        // Phần bàn tay: giữ nguyên kích thước ở đầu tay (tại con trỏ)
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex,
                x, length - HAND_ROWS, u, v + armRows,
                width, HAND_ROWS,
                width, HAND_ROWS,
                TEX_SIZE, TEX_SIZE);
    }
}
