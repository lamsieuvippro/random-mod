# Hand Cursor (Fabric 1.21.11)

Ẩn con trỏ chuột trong GUI (túi đồ, rương, anvil, enchanting, lò nung...) và thay bằng
cánh tay của người chơi (lấy từ skin) vươn ra từ mép dưới màn hình, đầu bàn tay nằm đúng chỗ chuột.

## Build
1. Cần JDK 21.
2. Tốt nhất: tạo project mẫu tại https://fabricmc.net/develop/template (MC 1.21.11, Yarn),
   rồi chép đè thư mục `src/` của gói này vào (và sửa package nếu muốn).
   Hoặc dùng thẳng gói này nếu bạn đã có Gradle wrapper: `./gradlew build`
3. File jar nằm ở `build/libs/` (không dùng file `-sources`). Bỏ vào `mods/` cùng Fabric API.

## Tuỳ chỉnh
- `HandCursorClient.ALL_SCREENS = true` để áp dụng cho mọi màn hình.
- `HandRenderer.SCALE` đổi độ dày cánh tay.
