package com.example.stationmenu;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record OpenStationPayload(int station) implements CustomPayload {
    public static final Id<OpenStationPayload> ID = new Id<>(Identifier.of("stationmenu", "open"));
    public static final PacketCodec<RegistryByteBuf, OpenStationPayload> CODEC =
            PacketCodecs.INTEGER.xmap(OpenStationPayload::new, OpenStationPayload::station).cast();

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
