package com.example.stationmenu;

import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

/** Vẽ bàn tay găng tím (kiểu video) bằng các ô fill, đầu ngón trỏ nằm đúng vị trí chuột. */
public final class HandCursor {
    private static final int OUT = 0xFF241038, PUR = 0xFF7B2FBE, LIT = 0xFFB57BEF,
            CUFF = 0xFFEDEAF2, SLEEVE = 0xFF5A1F94;

    private HandCursor() {}

    /** {x, y, w, h} */
    private static int[][] pointing() {
        return new int[][]{
                {0, 0, 6, 14},     // ngón trỏ
                {6, 6, 5, 8},      // ngón giữa (gập)
                {11, 8, 5, 6},     // ngón áp út
                {16, 10, 4, 4},    // ngón út
                {0, 12, 20, 12},   // lòng bàn tay
                {-6, 14, 7, 6}     // ngón cái
        };
    }

    private static int[][] fist() {
        return new int[][]{
                {0, 2, 5, 6}, {5, 0, 5, 8}, {10, 1, 5, 7}, {15, 3, 5, 5},
                {0, 4, 20, 14},
                {-5, 8, 6, 6}
        };
    }

    public static void draw(DrawContext ctx, int mx, int my, boolean pressed) {
        int ox = mx - 3;               // tâm ngón trỏ
        int oy = my + (pressed ? 0 : 0);
        int[][] parts = pressed ? fist() : pointing();
        int bodyBottom = pressed ? 18 : 24;

        // lượt 1: viền
        for (int[] p : parts) ctx.fill(ox + p[0] - 1, oy + p[1] - 1, ox + p[0] + p[2] + 1, oy + p[1] + p[3] + 1, OUT);
        ctx.fill(ox + 1, oy + bodyBottom - 1, ox + 19, oy + bodyBottom + 10, OUT);
        // lượt 2: màu găng
        for (int[] p : parts) ctx.fill(ox + p[0], oy + p[1], ox + p[0] + p[2], oy + p[1] + p[3], PUR);
        // điểm sáng
        if (!pressed) ctx.fill(ox + 1, oy + 1, ox + 2, oy + 12, LIT);
        else ctx.fill(ox + 1, oy + 3, ox + 4, oy + 4, LIT);
        // cổ tay: viền trắng + tay áo
        ctx.fill(ox + 2, oy + bodyBottom, ox + 18, oy + bodyBottom + 3, CUFF);
        ctx.fill(ox + 2, oy + bodyBottom + 3, ox + 18, oy + bodyBottom + 9, SLEEVE);
    }

    public static boolean isLeftDown(long window) {
        return GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    public static void hideSystemCursor(long window) {
        GLFW.glfwSetInputMode(window, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_HIDDEN);
    }
}
