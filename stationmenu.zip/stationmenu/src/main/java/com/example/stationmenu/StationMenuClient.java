package com.example.stationmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class StationMenuClient implements ClientModInitializer {
    private static final String[] NAMES = {"Bàn chế tạo", "Lò nung", "Đe", "Bàn enchant"};

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            boolean pause = screen instanceof GameMenuScreen;
            if (pause || screen instanceof InventoryScreen) {
                var buttons = Screens.getButtons(screen);
                for (int i = 0; i < NAMES.length; i++) {
                    final int id = i;
                    buttons.add(ButtonWidget.builder(Text.literal(NAMES[i]),
                                    b -> ClientPlayNetworking.send(new OpenStationPayload(id)))
                            .dimensions(6, 6 + i * 22, 90, 20).build());
                }
            }
            if (pause) {
                // Bàn tay thay con trỏ: vẽ sau cùng, ẩn con trỏ hệ thống
                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, delta) -> {
                    long win = client.getWindow().getHandle();
                    HandCursor.hideSystemCursor(win);
                    HandCursor.draw(ctx, mouseX, mouseY, HandCursor.isLeftDown(win));
                });
            }
        });
    }
}
