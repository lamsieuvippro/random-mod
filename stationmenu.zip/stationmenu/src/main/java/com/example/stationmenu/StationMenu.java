package com.example.stationmenu;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.screen.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class StationMenu implements ModInitializer {
    public static final int CRAFTING = 0, FURNACE = 1, ANVIL = 2, ENCHANT = 3;
    private static final Map<UUID, VirtualFurnace> FURNACES = new HashMap<>();

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(OpenStationPayload.ID, OpenStationPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(OpenStationPayload.ID,
                (payload, ctx) -> open(ctx.player(), payload.station()));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                VirtualFurnace f = FURNACES.get(p.getUuid());
                if (f != null) f.tick(server.getOverworld());
            }
        });

        // Trả đồ trong lò ảo khi người chơi thoát
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            VirtualFurnace f = FURNACES.remove(handler.getPlayer().getUuid());
            if (f == null) return;
            for (int i = 0; i < f.inv.size(); i++) {
                if (!f.inv.getStack(i).isEmpty()) handler.getPlayer().getInventory().offerOrDrop(f.inv.removeStack(i));
            }
        });
    }

    private static void open(ServerPlayerEntity player, int station) {
        var world = player.getEntityWorld();
        var pos = player.getBlockPos();
        // create(world,pos): để vật phẩm trong ô chế tạo được trả lại khi đóng; enchant tính giá sách quanh người chơi
        ScreenHandlerContext c = ScreenHandlerContext.create(world, pos);

        NamedScreenHandlerFactory f = switch (station) {
            case CRAFTING -> new SimpleNamedScreenHandlerFactory((id, inv, p) ->
                    new CraftingScreenHandler(id, inv, c) {
                        @Override public boolean canUse(PlayerEntity pl) { return true; }
                    }, Text.translatable("container.crafting"));
            case ANVIL -> new SimpleNamedScreenHandlerFactory((id, inv, p) ->
                    new AnvilScreenHandler(id, inv, c) {
                        @Override public boolean canUse(PlayerEntity pl) { return true; }
                    }, Text.translatable("container.repair"));
            case ENCHANT -> new SimpleNamedScreenHandlerFactory((id, inv, p) ->
                    new EnchantmentScreenHandler(id, inv, c) {
                        @Override public boolean canUse(PlayerEntity pl) { return true; }
                    }, Text.translatable("container.enchant"));
            case FURNACE -> {
                VirtualFurnace vf = FURNACES.computeIfAbsent(player.getUuid(), u -> new VirtualFurnace());
                yield new SimpleNamedScreenHandlerFactory((id, inv, p) ->
                        new FurnaceScreenHandler(id, inv, (Inventory) vf.inv, vf.props),
                        Text.translatable("container.furnace"));
            }
            default -> null;
        };
        if (f != null) player.openHandledScreen(f);
    }
}
