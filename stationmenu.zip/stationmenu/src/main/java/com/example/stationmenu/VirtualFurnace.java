package com.example.stationmenu;

import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.SmeltingRecipe;
import net.minecraft.recipe.input.SingleStackRecipeInput;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.server.world.ServerWorld;

/** Lò nung ảo của từng người chơi (không cần block). */
public class VirtualFurnace {
    public final SimpleInventory inv = new SimpleInventory(3); // 0 input, 1 fuel, 2 output
    private int burn, fuelTotal, cook, cookTotal = 200;

    public final PropertyDelegate props = new PropertyDelegate() {
        @Override public int get(int i) {
            return switch (i) { case 0 -> burn; case 1 -> fuelTotal; case 2 -> cook; case 3 -> cookTotal; default -> 0; };
        }
        @Override public void set(int i, int v) {
            switch (i) { case 0 -> burn = v; case 1 -> fuelTotal = v; case 2 -> cook = v; case 3 -> cookTotal = v; }
        }
        @Override public int size() { return 4; }
    };

    public void tick(ServerWorld world) {
        if (burn > 0) burn--;

        ItemStack in = inv.getStack(0), fuel = inv.getStack(1), out = inv.getStack(2);
        SingleStackRecipeInput input = new SingleStackRecipeInput(in);
        RecipeEntry<SmeltingRecipe> r = in.isEmpty() ? null
                : world.getRecipeManager().getFirstMatch(RecipeType.SMELTING, input, world).orElse(null);
        ItemStack result = r == null ? ItemStack.EMPTY : r.value().craft(input, world.getRegistryManager());
        boolean can = r != null && !result.isEmpty()
                && (out.isEmpty() || (ItemStack.areItemsAndComponentsEqual(out, result)
                && out.getCount() + result.getCount() <= out.getMaxCount()));

        if (burn == 0 && can && !fuel.isEmpty()) {
            int t = world.getFuelRegistry().getFuelTicks(fuel);
            if (t > 0) {
                burn = t; fuelTotal = t;
                boolean lava = fuel.isOf(Items.LAVA_BUCKET);
                fuel.decrement(1);
                if (lava) inv.setStack(1, new ItemStack(Items.BUCKET));
            }
        }
        if (burn > 0 && can) {
            cook++;
            cookTotal = r.value().getCookingTime();
            if (cook >= cookTotal) {
                cook = 0;
                if (out.isEmpty()) inv.setStack(2, result.copy()); else out.increment(result.getCount());
                in.decrement(1);
            }
        } else if (cook > 0) {
            cook = Math.max(cook - 2, 0);
        }
        inv.markDirty();
    }
}
