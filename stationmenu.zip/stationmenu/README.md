# Station Menu (Fabric 1.21.11)
- 4 nút (Bàn chế tạo, Lò nung, Đe, Bàn enchant) ở Inventory và Pause menu.
- Pause menu: con trỏ chuột thành bàn tay găng tím; bấm giữ chuột trái -> nắm tay.
Build: JDK 21 -> `gradle wrapper --gradle-version latest` -> `./gradlew build`
